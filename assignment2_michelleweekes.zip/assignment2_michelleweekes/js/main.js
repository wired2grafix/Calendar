// JavaScript Document
"use strict";
$(document).ready(function(){
    var weekDays = ["Sunday",
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday"];

    var allMonths = ["January",
                    "February",
                    "March",
                    "April",
                    "May",
                    "June",
                    "July",
                    "August",
                    "September",
                    "October",
                    "November",
                    "December"];

	
	// below gets the names of the week days (dayNamesDiv) 
	var dayNamesDiv = document.getElementById("dayNames");
    dayNamesDiv.innerHTML = "";
	
	document.getElementById("monthYear").innerHTML = allMonths[currentMonth]+" "+currentYear;
	
	// below we create a loop that builds the content
	for(var i=0; i<weekDays.length; i++) {
		
		//Don't forget to use += to add to the content rather than replace it
		dayNamesDiv.innerHTML += "<div>" + weekDays[i] + "</div>";
	}
	
	var allFlex = document.getElementsByClassName("flex-container");
	//Now we create a for loop that builds the content
    var myCount = 1;
		
    //This is where we can use our date functions instead
    var daysOffset = dayOffset(currentMonth, currentYear);
    var numberOfDaysToShow = daysInMonth(currentMonth, currentYear);
	
	for(var x=0; x<allFlex.length ; x++){
      allFlex[x].innerHTML = "";

        //Don't forget to use += to add to the content rather than replace it
          for(var j=0; j<7 ; j++){
            if(myCount> numberOfDaysToShow || daysOffset> 0){
              allFlex[x].innerHTML += "<div style='visibility: hidden'>"+myCount+"</div>";
              daysOffset--;

            } else {
                allFlex[x].innerHTML += "<div>"+myCount+"</div>";
                myCount++;
              }

          }
    }
	
});
	
	//Some handy ways to work with the date
	var currentYear = new Date().getFullYear();
	var currentMonth = new Date().getMonth();
//	var currentDay = new Date().getDate();

    //This function returns the number of days in a month
    function daysInMonth (month, year) {
      return new Date(year, (month+1), 0).getDate();
    }

    //This function returns the number of days before the 1st of the month
    function dayOffset(month, year) {
      return new Date(year, month, 1).getDay();
    }
		
    function monthDrop() {
      document.getElementById("myDropdown").classList.toggle("show");
    }

    // Close the dropdown menu if the user clicks outside of it
    window.onclick = function(event) {
      if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('show')) {
            openDropdown.classList.remove('show');
          }
        }
      }
    } 



